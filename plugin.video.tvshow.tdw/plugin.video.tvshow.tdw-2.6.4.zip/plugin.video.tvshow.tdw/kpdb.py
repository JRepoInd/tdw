﻿# -*- coding: utf-8 -*-
import sys, os, urllib

if sys.version_info.major > 2:  # Python 3 or later
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote
	import urllib2

#try:
#	import ssl
#	context = ssl.SSLContext(ssl.PROTOCOL_TLSv1)
#	opener = urllib2.build_opener(urllib2.HTTPSHandler(context=context))
#	urllib2.install_opener(opener)
#except: pass
import ssl
try:
	ctx = ssl.create_default_context()
	ctx.check_hostname = False
	ctx.verify_mode = ssl.CERT_NONE
except: pass

null = ''
true = True
false = False

def b2s(s):
	if sys.version_info.major > 2:
		try:s=s.decode('utf-8')
		except: pass
		try:s=s.decode('windows-1251')
		except: pass
		try:s=s.decode('cp437')
		except: pass
		return s
	else:
		return s

def GET(url):
	#urllib2.install_opener(urllib2.build_opener())
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	response = urllib2.urlopen(req, timeout=5, context=ctx)
	link=response.read()
	response.close()
	return b2s(link)

def get_path_old(id):
	pref='0'*(6-len(id))
	id=pref+id
	if len(id[:-4])==3:s1=chr(int(id[:-5])+87)+id[-5:-4]
	else:s1=id[:-4]
	s=[s1,id[-4:-2],id[-2:]]
	return s

def get_info_old(id):
	c=get_path_old(id)
	url='http://td-soft.narod.ru/kinodb/'+c[0]+'/'+c[1]+'.info'
	#hp=getURL(url)
	f=urllib.urlopen(url)
	hp=f.read()
	cinfo=eval(hp)
	info=cinfo[id]
	return info

def get_path(id):
	pref='xxx'
	id=pref+id
	s=[id[-2:],id[-4:-2]]
	return s

def get_info(id):
	c=get_path(id)
	url='http://td-soft.narod.ru/db/'+c[0]+'/'+c[1]+'.info'
	cinfo=eval(GET(url).replace('\xa0',' '))
	info=cinfo[id]
	return info

def uni(t):
	return t.lower().replace("the ", '').replace("«",'').replace("»",'').replace('"', '').replace("'", '').replace("`", '').replace(" ", '').replace("-", '').replace(":", '').replace("/", '').replace("\\", '').replace("&", '').strip()

ttl2id={}
def upd_ttl2id():
	global ttl2id
	url='http://td-soft.narod.ru/db/ttl2id.info'
	ttl2id =eval(GET(url))

def search_id(ttl, year=0):
	print('seach_id: '+ttl)
	if ttl2id=={}: upd_ttl2id()
	try: year = int(year)
	except: year = 0
	#url='http://td-soft.narod.ru/db/ttl2id.info'
	D=ttl2id
	L=[]
	for k in D.keys():
		L.append(k)
	Dy={}
	if ttl in L: Dy = D[ttl]
	unit = uni(ttl)
	for i in L:
		if uni(i) == unit: 
			Dy = D[i]
			break
	
	#print (Dy)
	Ly=[]
	for k in Dy.keys():
		Ly.append(k)

	if year == 0: 
		if len(Ly)>0: return Dy[Ly[0]]
	else:
		if str(year)   in Ly: return Dy[str(year)]
		if str(year+1) in Ly: return Dy[str(year+1)]
	return ''

#print(search_id('Terminator'))
#print(get_info('4472346'))