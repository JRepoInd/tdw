#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, sys, json, time
import requests, base64

prov = 'HDVB'
serv = 'http://hd.kp-ppc.xyz/iplayer/pl.php?kp='
D_UA='|User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 OPR/77.0.4054.203'

if sys.version_info.major > 2:  # Python 3 or later
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote
	import urllib2


def b2s(s):
	if sys.version_info.major > 2:
		try:s=s.decode('utf-8')
		except: pass
		try:s=s.decode('windows-1251')
		except: pass
		try:s=s.decode('cp437')
		except: pass
		return s
	else:
		return s

def test_torrent(t):
	torrent_data = repr(t)
	if 'd8:' not in torrent_data and 'd7:' not in torrent_data and ':announc' not in torrent_data: True
	else: return False

def CRC32(buf):
		buf = repr(buf)
		import binascii
		if sys.version_info.major > 2: buf = (binascii.crc32(buf.encode('utf-8')) & 0xFFFFFFFF)
		else: buf = (binascii.crc32(buf) & 0xFFFFFFFF)
		r=str("%08X" % buf)
		return r


def findall(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

def add_ch(id, D):
	try:
		import settings
		settings.set(prov+'_ch_'+id, {'ch':D, 'tm': time.time()})
	except: pass


def get_ch(id):
	try:
		import settings
		Dch  = settings.get(prov+'_ch_'+id)
		D  = Dch['ch']
		tm = Dch['tm']
		if (time.time()-tm<3600*3): return D
		else: return None
	except:
		return None

def GET2(target, referer='', post=None):
		import requests
		s = requests.session()
		r=s.get(target, timeout=(0.6, 4), verify=False).text
		return r


def GET(target, referer='', post=None):
	urllib2.install_opener(urllib2.build_opener())
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return b2s(http)
	except:
		return GET2(target)

def is_libreelec():
	try:
		if os.path.isfile('/etc/os-release'):
			f = open('/etc/os-release', 'r')
			str = f.read()
			f.close()
			if "LibreELEC" in str and "Generic" in str: return True
	except: pass
	return False

def rt(s):
	if sys.version_info.major > 2: return s
	try:s=s.decode('utf-8')
	except: pass
	if not is_libreelec():
		try:s=s.decode('windows-1251')
		except: pass
	try:s=s.encode('utf-8')
	except: pass
	return s


def decode64(hash_str):
    return base64.b64decode(hash_str.encode('utf-8')+b'==').decode('utf-8')

def prov_7(kp_id, serial=False):
    finded_videos = []
    url = "http://hd.kp-ppc.xyz/iplayer/pl.php?kp="+kp_id
    base64_body = requests.get(url, headers={'Referer': "ya.ru"}).text
    if base64_body == 'video_not_found':
        return finded_videos
    items = json.loads(decode64(base64_body).replace('},]','}]'))['playlist']
    #print (items)
    if serial:
        return items
        try:
            items = items[int(season_id)-1]['folder'][int(episode_id)-1]['folder']
        except:
            return finded_videos
    for item in items:
        title = item.get('title',False) or item.get('comment',False)
        video_url = item['file'].split(']')[-1]
        if '/1080' in video_url: q = '1080p'
        elif '/720' in video_url: q = '720p'
        elif '/480' in video_url: q = '480p'
        else: q = '360p'
        video_ext = video_url.split('.')[-1]
        finded_videos.append({"sids":'0',"size":'0', "title": '[ '+prov+' ] '+title+ ' '+q, "url":video_url})
    return finded_videos


def get_kp_id(imdb_id):
	url='https://api.manhan.one/externalids?serial=1&imdb_id='+imdb_id
	j=GET(url)
	D=json.loads(j)
	kp_id=D['kinopoisk_id']
	return kp_id

def get_serial_episodes(info={}):
	Lr=[]
	imdb_id = str(info['imdb_id'])
	Dc=get_ch(imdb_id)
	if Dc!=None: return Dc

	kp_id = get_kp_id(imdb_id)
	#kp_id = str(info['id'])
	Ls = prov_7(kp_id, True)
	S=0
	D={}
	for si in Ls:
		#print si['folder'][0]['folder'][0]['comment']
		
		S+=1
		SS=str(S)
		if len(SS)==1:SS='0'+SS
		Lt1=si['folder']#[0]['folder']
		E=0
		if S not in D.keys(): D[S]={}
		
		for e_item in Lt1:
			E+=1
			Lt2=e_item['folder']
			if E not in D[S].keys(): D[S][E]=[]
			for item in Lt2:
				t = item['comment']
				if '|' in t: t=t.split('|')[-1]
				video_url = item['file'].split(']')[-1]
				t_id = CRC32(t)
				if '/1080' in video_url: q = '1080p'
				elif '/720' in video_url: q = '720p'
				elif '/480' in video_url: q = '480p'
				else: q = '360p'
				#Lr.append ({"sids":'0',"size":'0', "title": '[ '+prov+' ] s'+str(SS)+' '+t+' '+q, "url":"manhan_"+prov+"_season:"+kp_id+'_'+str(S)+'_'+t_id})
			
				#Lr.append ({"translate":t, "season":S, "quality":q, "title": '[ '+prov+' ] s'+SS+' '+t+' '+q, "url":video_url})
				D[S][E].append({'translate':t,'quality':q, 'url':video_url})
	if D!={}: add_ch(imdb_id, D)
	return D





