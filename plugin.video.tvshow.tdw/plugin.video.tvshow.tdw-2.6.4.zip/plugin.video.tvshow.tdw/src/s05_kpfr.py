#!/usr/bin/python
# -*- coding: utf-8 -*-

#import time
import os, sys
#import string, xbmcgui, xbmcplugin, xbmcaddon
#try:
#  from xbmcvfs import translatePath
#except (ImportError, AttributeError):
#  from xbmc import translatePath
#-------------------------------
icon = ""
siteUrl = 'w1.kpfr.wiki'
httpSiteUrl = 'http://' + siteUrl
#__settings__ = xbmcaddon.Addon(id='plugin.video.KinoPoisk.ru')

if sys.version_info.major > 2:  # Python 3 or later
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote
	import urllib2


def b2s(s):
	if test_torrent(s)==False: return s
	if sys.version_info.major > 2:
		try:s=s.decode('utf-8')
		except: pass
		try:s=s.decode('windows-1251')
		except: pass
		try:s=s.decode('cp437')
		except: pass
		return s
	else:
		return s

def test_torrent(t):
	torrent_data = repr(t)
	if 'd8:' not in torrent_data and 'd7:' not in torrent_data and ':announc' not in torrent_data: True
	else: return False


def unlock(url):
	url = url.replace('http://findmagnet.org','https://findmagnet-org.translate.goog')+'&_x_tr_sl=auto&_x_tr_tl=ru&_x_tr_hl=ru&_x_tr_pto=wapp'
	print (url)
	return url

def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return translatePath(x)

def encod(x):
	try:x=x.decode('Windows-1251')
	except:pass
	try:x=x.encode('utf-8')
	except:pass
	return x


def coder(x):
	x=x.decode('utf-8')
	x=x.encode('Windows-1251')
	return x

def lower(t):
	RUS={"А":"а", "Б":"б", "В":"в", "Г":"г", "Д":"д", "Е":"е", "Ё":"ё", "Ж":"ж", "З":"з", "И":"и", "Й":"й", "К":"к", "Л":"л", "М":"м", "Н":"н", "О":"о", "П":"п", "Р":"р", "С":"с", "Т":"т", "У":"у", "Ф":"ф", "Х":"х", "Ц":"ц", "Ч":"ч", "Ш":"ш", "Щ":"щ", "Ъ":"ъ", "Ы":"ы", "Ь":"ь", "Э":"э", "Ю":"ю", "Я":"я"}
	for i in range (65,90):
		t=t.replace(chr(i),chr(i+32))
	for i in RUS.keys():
		t=t.replace(i,RUS[i])
	return t


def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2


def debug(s):
	fl = open(ru(os.path.join( addon.getAddonInfo('path'),"test.txt")), "wb")
	fl.write(s)
	fl.close()


def GET(target, referer='http://torrent.by', post=None):
		#if __settings__.getSetting("antizapret") == "true": target = unlock(target)
		if sys.version_info.major > 2 and post!=None: post = post.encode()
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36 OPR/50.0.2762.67')
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return b2s(http)


def GET(url, referer=''):
	#if __settings__.getSetting("antizapret") == "true": url = unlock(url)
	try:
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 OPR/77.0.4054.203')
		req.add_header('Referer', referer)
		req.add_header('Content-Type', 'application/json')
		response = urllib2.urlopen(req)#, context=ctx)
		print (response.info())
		if response.info().get('Content-Encoding') == 'gzip':
			from StringIO import StringIO
			import gzip
			buf = StringIO(response.read())
			f = gzip.GzipFile(fileobj=buf)
			data = f.read()
		else:
			data = response.read()
		response.close()
		return data
	except:
		print ('err')
		return ''

def GET2(url, Referer = ''):
#	try:
		import requests
		response = requests.get(url, verify=False)
		link=response.text
		return link
#	except:
#		print ('err')
#		return ''
'''
def clear(s):
	L=['<b>','</b>','</a>','</td>']
	for i in L:
		s=s.replace(i,'')
	s=s.replace(chr(10),'').replace(chr(13),'').replace('\t','').strip()
	return s
'''

def Parser(hp):
	#hp.replace('Размер</td></tr>','')
	Lout=[]
	L = mfindal(hp,'<td><center>', '</tr><tr>')#</td>
	for i in L:
		#i=i+"<"
		i=i.replace(chr(10),'').replace(chr(13),'').replace('\t','')
		#print (i)
		try:
					url ='magnet:'+mfind(i, 'magnet:', '"><img src=')
					#url = url.replace('&amp;_x_tr_sl=auto&amp;_x_tr_tl=ru&amp;_x_tr_hl=ru&amp;_x_tr_pto=wapp', '')[:60]
					title = mfind(i, "<div class='bbs'>", '</div>').replace('<font color=#cc0000>','').strip()
					size = mfind(i, "sizepiza'>", '</').replace('&nbsp;','').replace('<td>','').strip()
					if 'MB' in size: size = size[:size.find('.')]+'MB'
					elif len(size)-size.find('.')>4: 
						size = size[:size.find('.')+3]+'GB'
					sids = mfind(i, "sirazd'>", '</')
					if title !='': Lout.append({"sids":sids, "size":size, "title":title, "url":url, "quality": ''})
		except:
					print ('err')
	return Lout


def Storr(info):
	text=info['originaltitle']
	url=httpSiteUrl+'/torrent.php?name='+quote(text)#.replace(' ','+')
	#print (url)
	http=GET(url,httpSiteUrl)
	#print (http)
	Lout=Parser(http)
	if Lout==[]: 
		http=GET2(url,httpSiteUrl)
		Lout=Parser(http)
	#	text=info['title']
	#	url=httpSiteUrl+'/?q='+quote(text.replace(' ','+'))
	#	http=GET(url,httpSiteUrl)
	#	Lout=Parser(http)
	return Lout



class Tracker:
	def __init__(self):
		pass

	def Search(self, info):
		Lout=Storr(info)
		return Lout

#print (Storr({'originaltitle':'terminator', 'title':'terminator'}))
